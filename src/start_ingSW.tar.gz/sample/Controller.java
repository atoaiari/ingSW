package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    private TextField myTextField;

    @FXML
    private ListView<String> myListView;

    @FXML
    private Button myButton;

    private ObservableList<String> lista;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lista = FXCollections.observableArrayList();
        myButton.setOnAction(e -> manageClick());
        System.out.println(myListView);
        myListView.setItems(lista);
    }

    private void manageClick() {
        String testo = myTextField.getText();
        lista.add(testo);

    }
}